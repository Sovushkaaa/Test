﻿static void Main(string[] args)
{}
public class Num()
{
    public static int[] Bubble(int[] numbers)
    {
        for (int i = 0; i < numbers.Length; i++)
        {
            for (int j = 0; j < numbers.Length - i - 1; j++)
            {
                if (numbers[j] > numbers[j + 1])
                {
                    int tmp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = tmp;
                }
            }
        }
        return numbers;
    }
    public static int[] Chose(int[] num3)
    {
        int n = num3.Length;
        for (int i =0; i < n - 1; i++)
        {
            int mIndex = i;
            for (int j = i + 1; j < n; j++)
            {
                if (num3[j] < num3[mIndex])
                {
                    mIndex = j;
                }
            }
            int tmp = num3[mIndex];
            num3[mIndex] = num3[i];
            num3[i] = tmp;
        }
        return num3;
    }
    public static int[] Quick(int[] num2, int low, int high)
    {
        int pivot = num2[num2.Length - 1];
        int i = -1;
        for (int j = 0; j < num2.Length - 1; j++)
        {
            if (num2[j] <= pivot)
            {
                i++;
                int tmp = num2[i];
                num2[i] = num2[j];
                num2[j] = tmp;
            }
        }
        int tmp2 = num2[i + 1];
        num2[i + 1] = num2[num2.Length - 1];
        num2[num2.Length - 1] = tmp2;
        Quick(num2, 0, i);
        Quick(num2, i + 2, num2.Length - 1);
        return num2;
    }

    // Console.WriteLine($"{a}-{b}");
    //(a, b) = (b, a); 
    //Console.WriteLine($"{a}-{b}");перестановка для текущего примера,
    public static (int, int) Reverse((int, int) nums)
    {
        nums.Item1 = nums.Item1 ^ nums.Item2;
        nums.Item2 = nums.Item1 ^ nums.Item2;
        nums.Item1 = nums.Item1 ^ nums.Item2;
        return nums;
    }
}
