namespace Test1
{
    public class UnitTest1
    {
        [Fact]
        public void Bubble()
        {
            var mockData = new int[] {1, 2, 3, 4 , 5};
            var testData = new int[] { 5, 3, 4, 2, 1 };
            testData = Num.Bubble(testData);
            Assert.Equal<int[]>(mockData, testData);
        }
        [Fact]
        public void Quick()
        {
            var mockData = new int[] { 1, 2, 3, 4, 5 };
            var testData = new int[] { 5, 3, 4, 2, 1 };
            testData = Num.Quick(testData, 2, 4);
            Assert.Equal<int[]>(mockData, testData);
        }
        [Fact]
        public void Chose()
        {
            var mockData = new int[] { 1, 2, 3, 4, 5 };
            var testData = new int[] { 5, 3, 4, 2, 1 };
            testData = Num.Chose(testData);
            Assert.Equal<int[]>(mockData, testData);
        }
        [Fact]
        public void TBubble()
        {
            var mockData = new int[] { 1, 2, 3, 4, 5 };
            var testData = new int[] { 5, 3, 4, 2, 1 };
            DateTime curTime = DateTime.Now;
            testData = Num.Bubble(testData);
            DateTime elapseTime = DateTime.Now;
            TimeSpan span = elapseTime - curTime;
            Assert.True(Math.Abs(span.Milliseconds) <= 10);
        }
        [Fact]
        public void TestTimeQuick()
        {
            var mockData = new int[] { 1, 2, 3, 4, 5 };
            var testData = new int[] { 5, 3, 4, 2, 1 };
            DateTime curTime = DateTime.Now;
            testData = Num.Quick(testData, 2, 4);
            DateTime elapseTime = DateTime.Now;
            TimeSpan span = elapseTime - curTime;
            Assert.True(Math.Abs(span.Milliseconds) <= 10);
        }
        [Fact]
        public void TestTimeChose()
        {
            var mockData = new int[] { 1, 2, 3, 4, 5 };
            var testData = new int[] { 5, 3, 4, 2, 1 };
            DateTime curTime = DateTime.Now;
            testData = Num.Chose(testData);
            DateTime elapseTime = DateTime.Now;
            TimeSpan span = elapseTime - curTime;
            Assert.True(Math.Abs(span.Milliseconds) <= 10);
        }
        [Fact]
        public void TestReverse()
        {
            (int, int) mockData = (1, 2);
            (int, int) testData = (2, 1);
            testData = Num.Reverse(testData);
            Assert.Equal(mockData, testData);
        }
    }
}